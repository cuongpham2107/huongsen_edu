<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CategoryAdmissionArticle extends Model
{
    
}
