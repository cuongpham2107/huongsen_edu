@extends('pages.layouts.default')

@section('style')
@endsection

@section('content')
    {{-- @dd($pageMeta) --}}
    <!-- Breadcromb Wrapper Start -->
    <div class="breadcromb-wrapper">
        <div class="breadcromb-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="breadcromb-left">
                        <h3>{{ $pageMeta['title'] }}</h3>
                    </div>
                </div>
            </div>
            <div class="breadcromb-text">
                <ul>
                    <li><a href="{{ url('/') }}"><i class="fa fa-home"></i>Trang chủ</a></li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li>Về chúng tôi</li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li>{{ $pageMeta['title'] }}</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcromb Wrapper End -->
    <!-- Inner Page Wrapper Start -->
    <div class="inner-page-wrapper blog-wrapper blog-single course-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 pull-left">
                    <div class="blog-single-img">
                        @if($about->image)
                            <img src="{{Voyager::image($about->image)}}" title="" style="height: 550px; object-fit: cover">
                        @endif
                        <h2>{{$about->title}}</h2>
                        <ul class="list-inline list-blog-single">
                            <li><i class="fa fa-user" aria-hidden="true"></i><a href="javascript:void(0)">Admin</a></li>
                            {{-- <li><i class="fa fa-comments-o" aria-hidden="true"></i><a href="javascript:void(0)">4
                                    Comments</a></li> --}}
                        </ul>
                        <p>{!! $about->body !!}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Inner Page Wrapper End -->
    <!-- Our Services Wrapper Start -->
    <section class="our-team-wrapper" style="padding: 0 0 170px;">
        <div class="container">
            <div class="title">
                <h2>Đơn vị thành viên</h2>
                <div><span></span></div>
            </div>
            <div class="row">
                @if($our_team)
                    @foreach ($our_team as $item)
                        <div class="col-sm-6 col-md-4">
                            <div class="single-blog">
                                <div class="image"><a href="{{route('static-data.show',$item->slug)}}">
                                        <img src="{{Voyager::image($item->image)}}" alt="" width="360" height="240"
                                             style="object-fit: cover">
                                    </a>
                                    <a href="{{route('static-data.show',$item->slug)}}" class="overlay-box"><span
                                                class="icon fa fa-link"></span></a>
                                </div>
                                <div class="blog-content">
                                    <div class="blog-title"> <span>{{date("d", strtotime($item->created_at))}}<br>
                    {{\Carbon\Carbon::parse($item->created_at)->locale('vi-VN')->translatedFormat("F")}}
                  </span>
                                        <h3><a href="{{route('static-data.show',$item->slug)}}">{{$item->title}}</a></h3>
                                    </div>
                                    <p>{{$item->excerpt}}</p>
                                    <a class="read-more" href="{{route('static-data.show',$item->slug)}}">Xem thêm<i
                                                class="fa fa-long-arrow-right"></i> </a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @endif
            </div>
        </div>
    </section>
    <!-- Our Services End -->
@endsection

@section('js')
@endsection
