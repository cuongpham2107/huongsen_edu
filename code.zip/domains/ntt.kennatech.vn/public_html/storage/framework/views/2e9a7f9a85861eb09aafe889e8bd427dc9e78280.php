
<?php
    $admissionArticle = \App\AdmissionArticle::where('status','published')->get()->count();
    $posts = TCG\Voyager\Models\Post::where('status','published')->get()->count();
    $unitInformationsts = \App\UnitInformation::where('status','published')->get()->count();
    $cooperationLink =  \App\CooperationLink::where('status','published')->get()->count();
    $documentKnowledge = \App\DocumentKnowledge::where('status','published')->get()->count();
    $abroadStudy = \App\AbroadStudy::where('status','published')->get()->count();
    // dd($admissionArticle);
?>
<div class="panel panel-default panel-sidebar">
  <div class="panel-heading">
      <h3><span class="title-about">Danh mục</span> </h3>
  </div>
  <div class="panel-body">
      <ul class="list-group list-sidebar">
          <li class="list-group-item"><a href="<?php echo e(route('admission-articles.index')); ?>">Tuyển sinh <span
                      class="pull-right"><?php echo e($admissionArticle); ?></span></a></li>
          <li class="list-group-item"><a href="<?php echo e(route('posts.index')); ?>">Tin tức sự kiện <span
                      class="pull-right"><?php echo e($posts); ?></span></a></li>
          <li class="list-group-item"><a href="<?php echo e(route('unit-information.index')); ?>">Đơn vị trực thuộc <span
                      class="pull-right"><?php echo e($unitInformationsts); ?></span></a></li>
          <li class="list-group-item"><a href="<?php echo e(route('cooperation-links.index')); ?>">Liên kết hợp tác <span
                      class="pull-right"><?php echo e($cooperationLink); ?></span></a></li>
          <li class="list-group-item"><a href="<?php echo e(route('document-knowledge.index')); ?>">Thư viện <span
                      class="pull-right"><?php echo e($documentKnowledge); ?></span></a></li>
          <li class="list-group-item"><a href="<?php echo e(route('abroad-studies.index')); ?>">Tư vấn du học<span
                      class="pull-right"><?php echo e($abroadStudy); ?></span></a></li>
      </ul>
  </div>
</div><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/layouts/partials/category.blade.php ENDPATH**/ ?>