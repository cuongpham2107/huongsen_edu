<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcromb Wrapper Start -->
    <div class="breadcromb-wrapper">
        <div class="breadcromb-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="breadcromb-left">
                        <h3>Tuyển sinh</h3>
                    </div>
                </div>
            </div>
            <div class="breadcromb-text">
                <ul>
                    <li><a href="index.html"><i class="fa fa-home"></i>Trang chủ</a></li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li>Tuyển sinh</li>
                    
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcromb Wrapper End -->
    <!-- Inner Page Wrapper Start -->
    <div class="inner-page-wrapper blog-wrapper blog-full-width">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <?php if($post): ?>
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="blog-list clearfix">
                                <div class="blog-list-img"> <a href="<?php echo e(route('admission-articles.show',$item->slug)); ?>"> 
                                <img src="<?php echo e(Voyager::image($item->image)); ?>" width="330" height="270" style="object-fit: cover"
                                            alt="" class="img-responsive" title=""> </a> 
                                     
                                        <span class="sticker-round "><?php echo e(date("d", strtotime($item->created_at))); ?><br>
                                            <?php echo e(\Carbon\Carbon::parse($item->created_at)->locale('vi-VN')->translatedFormat("F")); ?> </span>
                                    </div>
                                <div class="blog-list-details"> <a href="<?php echo e(route('admission-articles.show',$item->slug)); ?>">
                                        <h4><?php echo e($item->title); ?></h4>
                                    </a>
                                    <ul class="list-inline list-blog">
                                        <li><i class="fa fa-user" aria-hidden="true"></i><a href="#">Admin</a></li>
                                        
                                    </ul>
                                    <p class="line-clamp"><?php echo e($item->excerpt); ?></p>
                                    <a href="<?php echo e(route('admission-articles.show',$item->slug)); ?>" class="btn">Xem thêm</a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col-sm-12">
                    <?php echo e($post->links('pages.layouts.partials.paginate')); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- Inner Page Wrapper End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/admission-articles/index.blade.php ENDPATH**/ ?>