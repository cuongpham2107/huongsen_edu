


 <?php
   $banner = \App\Banner::where('status','PUBLISHED')->where('type','banner')->limit(3)->get();   
?>
<?php if($banner): ?>
<div class="banner-wrapper">
  <div id="first-slider" class="">
    <div id="carousel-example-generic" class="carousel slide carousel-fade">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
        <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
      </ol>
      <!-- Wrapper for slides -->
      <div class="carousel-inner" role="listbox">
        <!-- Item 1 -->
        <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item slide<?php echo e($key+1); ?> <?php if($key == 0): ?> active <?php endif; ?>" style="background-image: url(<?php echo e(Voyager::image($item->background)); ?>)">
            <div class="row">
              <div class="container">
                
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
       
      </div>
      <!-- End Wrapper for slides--> <a style="background-image: none" class="left carousel-control" href="#carousel-example-generic" role="button"
        data-slide="prev"> <i class="fa fa-angle-left"></i><span class="sr-only">Trước</span> </a> <a style="background-image: none"
        class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next"> <i
          class="fa fa-angle-right"></i><span class="sr-only">Kế tiếp</span> </a>
    </div>
  </div>
</div>
<?php endif; ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/layouts/partials/banner.blade.php ENDPATH**/ ?>