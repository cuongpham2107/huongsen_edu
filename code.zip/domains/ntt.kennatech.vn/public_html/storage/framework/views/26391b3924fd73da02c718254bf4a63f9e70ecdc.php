<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <!-- Breadcromb Wrapper Start -->
    <div class="breadcromb-wrapper">
        <div class="breadcromb-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="breadcromb-left">
                        <h3><?php echo e($pageMeta['title']); ?></h3>
                    </div>
                </div>
            </div>
            <div class="breadcromb-text">
                <ul>
                    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i>Trang chủ</a></li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li><?php echo e($pageMeta['title']); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcromb Wrapper End -->
    <!-- Inner Page Wrapper Start -->
    <div class="inner-page-wrapper blog-wrapper blog-single course-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 pull-left">
                    <div class="blog-single-img"> 
                        <?php if($staticData->image): ?>
                            <img src="<?php echo e(Voyager::image($staticData->image)); ?>" title="" style="height: 550px; object-fit: cover">
                        <?php endif; ?>  
                        <h2><?php echo e($staticData->title); ?></h2>
                        <ul class="list-inline list-blog-single">
                            <li><i class="fa fa-user" aria-hidden="true"></i><a href="javascript:void(0)">Admin</a></li>
                            
                        </ul>
                        <p><?php echo $staticData->body; ?></p>
                        <ul class="list-inline list-social-color">
                            <li><a target="_blank" href="https://www.facebook.com/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-facebook"></i></a></li>
                            <li><a target="_blank" href="https://twitter.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Inner Page Wrapper End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/static-data/show.blade.php ENDPATH**/ ?>