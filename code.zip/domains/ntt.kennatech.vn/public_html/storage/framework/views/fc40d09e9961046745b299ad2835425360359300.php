<?php
    $gallery = \App\StaticData::where('status','PUBLISHED')->where('type','footer-image')->first();
?>
<div class="footer-wrapper">
  <div class="footer-top-area">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="footer-about-info-area footer-top-content">
            <div class="footer-widget-heading">
              <h3>Về chúng tôi</h3>
            </div>
            <div class="footer-widget-content">
              <p><?php echo e(setting('site.title')); ?> </p>
              <p><?php echo e(setting('site.description')); ?></p>
              <ul class="footer-social-menu list-inline">
                <li><a target="_blank" href="<?php echo e(setting('social-media.facebook')); ?>"><i class="fa fa-facebook"></i></a></li>
                <li><a target="_blank" href="<?php echo e(setting('social-media.twitter')); ?>"><i class="fa fa-twitter"></i></a></li>
                <li><a target="_blank" href="<?php echo e(setting('social-media.instagram')); ?>"><i class="fa fa-instagram"></i></a></li>
                <li><a target="_blank" href="<?php echo e(setting('social-media.youtube')); ?>"><i class="fa fa-youtube"></i></a></li>
                
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="footer-tags-widget">
            <div class="footer-widget-heading">
              <h3>Liên kết nhanh</h3>
            </div>
            <div class="footer-widget-content">
              <ul class="footer-widget-menu">
                <li> <a href="<?php echo e(url('/')); ?>">Trang chủ</a> </li>
                <li> <a href="<?php echo e(route('page.show','ve-chung-toi')); ?>">Về chúng tôi</a></li>
                <li> <a href="<?php echo e(route('admission-articles.index')); ?>">Tuyển sinh</a></li>
                <li> <a href="<?php echo e(route('posts.index')); ?>">Tin tức - sự kiện</a> </li>
                <li> <a href="<?php echo e(route('unit-information.index')); ?>">Đơn bị trực thuộc</a> </li>
                <li> <a href="<?php echo e(route('cooperation-links.index')); ?>">Liên kết hợp tác</a> </li>
                <li> <a href="<?php echo e(route('document-knowledge.index')); ?>">Thư viện</a> </li>
                <li> <a href="<?php echo e(route('abroad-studies.index')); ?>">Tư vấn du học</a> </li>
                <li> <a href="<?php echo e(route('contact.index')); ?>">Liên hệ</a> </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="footer-contact">
            <div class="footer-widget-heading">
              <h3>Liên hệ với chúng tôi</h3>
            </div>
            <div class="footer-widget-content">
              <p>Hãy liên hệ với chúng tôi để nhận được những thông tin mới nhất cập nhập từ chúng tôi.</p>
              <ul class="footer-conatct-menu">
                <li> <a href="mailto:<?php echo e(setting('site.email')); ?>"><i class="fa fa-envelope"></i><span>Email :</span>
                  <?php echo e(setting('site.email')); ?></a> </li>
                <li> <a href="tell:<?php echo e(setting('site.phone')); ?>"><i class="fa fa-phone"></i> <span>Phone : </span> <?php echo e(setting('site.phone')); ?></a> </li>
                <li> <a href="#"><i class="fa fa-map-o"></i><span>Address :</span> <?php echo e(setting('site.address')); ?></a> </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="footer-instagram">
            <div class="footer-widget-heading">
              <h3>Hình ảnh</h3>
            </div>
            <div class="footer-instagram-widget footer-widget-content"> 
              <?php if(isset($gallery) && count(json_decode($gallery->images)) > 0): ?>
                <?php $__currentLoopData = json_decode($gallery->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="#"><img
                    src="<?php echo e(Voyager::image($item)); ?>" alt=""></a> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
                </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright-wrapper">
    <div class="container">
      <p>&copy; Copyright <span id="year"></span> Nguyen Tat Thanh | All rights reserved. Created by <a href="kennatech.vn">KennaTech</a>.</p>
    </div>
  </div>
</div><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/layouts/partials/footer.blade.php ENDPATH**/ ?>