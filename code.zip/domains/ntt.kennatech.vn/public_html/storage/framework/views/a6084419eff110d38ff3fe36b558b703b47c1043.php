<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="description" content="<?php echo e($pageMeta['meta_description'] ?? setting('site.description')); ?>" />
  <meta name="content" content="<?php echo e($pageMeta['meta_content'] ?? setting('site.content')); ?>" />

  <title><?php echo e($pageMeta['title'] ?? setting('site.title')); ?></title>

  <link rel="shortcut icon" href="<?php echo e(\TCG\Voyager\Facades\Voyager::image(setting('site.logo'))); ?>" type="image/png">

  <meta property="og:image"
    content="<?php echo e(\TCG\Voyager\Facades\Voyager::image($pageMeta['image'] ?? setting('site.logo'))); ?>" />
  <meta property="og:url" content="<?php echo e(\Request::fullUrl()); ?>" />
  <meta property="og:type" content="Website" />
  <meta property="og:title" content="<?php echo e($pageMeta['title'] ?? setting('site.title')); ?>" />
  <meta property="og:description" content="<?php echo e($pageMeta['meta_description'] ?? setting('site.description')); ?>" />
  <meta property="og:content" content="<?php echo e($pageMeta['meta_content'] ?? setting('site.content')); ?>" />
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!-- Font Awesome CSS-->
  <link href="<?php echo e(asset('assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <!-- Animate CSS -->
  <link href="<?php echo e(asset('assets/animate/animate.css')); ?>" rel="stylesheet">
  <!-- Mobile Menu Css -->
  <link href="<?php echo e(asset('assets/css/slicknav.css')); ?>" rel="stylesheet">
  <!-- Owl Carousel -->
  <link href="<?php echo e(asset('assets/owl-carousel/css/owl.carousel.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/owl-carousel/css/owl.theme.css')); ?>" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.ico')); ?>">

  <?php echo $__env->yieldContent('style'); ?>


</head>

<body>

  
  
   <!-- Pre Loader -->
   
   <!-- Header Start -->
    <header>
      <?php echo $__env->make('pages.layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php $__env->startSection('sidebar'); ?>
      <?php echo $__env->yieldSection(); ?>
    </header>
   <!-- Header End -->
  
   <?php echo $__env->yieldContent('content'); ?>
   <?php echo $__env->make('pages.layouts.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- Footer Wrapper Start -->
   <?php echo $__env->make('pages.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- Footer Wrapper End -->

    


   


  
  <script src="<?php echo e(asset('assets/jquery/jquery-1.12.0.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/jquery/plugin.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/jquery/plugins.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/jquery/slider.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/owl-carousel/js/owl.carousel.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/wow/wow.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/jquery/jquery.slicknav.js')); ?>"></script>
  <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
  <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/layouts/default.blade.php ENDPATH**/ ?>