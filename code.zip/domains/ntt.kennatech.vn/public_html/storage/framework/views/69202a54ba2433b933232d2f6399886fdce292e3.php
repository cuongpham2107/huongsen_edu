<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcromb Wrapper Start -->
    <div class="breadcromb-wrapper">
        <div class="breadcromb-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="breadcromb-left">
                        <h3><?php echo e($category->name); ?></h3>
                    </div>
                </div>
            </div>
            <div class="breadcromb-text">
                <ul>
                    <li><a href="index.html"><i class="fa fa-home"></i>Trang chủ</a></li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li><?php echo e($category->name); ?></li>
                    
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcromb Wrapper End -->
    <!-- Inner Page Wrapper Start -->
    <div class="inner-page-wrapper blog-wrapper blog-right">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-7 pull-left">
                    <div class="row">
                      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-sm-12">
                          <div class="single-blog">
                              <div class="image"> <a href="<?php echo e(route('admission-articles.show',$item->slug)); ?>">
                                <img src="<?php echo e(Voyager::image($item->image)); ?>" width="360" height="240" style="object-fit: cover"
                                          alt=""></a>
                                  <a href="<?php echo e(route('admission-articles.show',$item->slug)); ?>" class="overlay-box"><span class="icon fa fa-link"></span></a>
                              </div>
                              <div class="blog-content">
                                  <div class="blog-title">  <span ><?php echo e(date("d", strtotime($item->created_at))); ?><br>
                                    <?php echo e(\Carbon\Carbon::parse($item->created_at)->locale('vi-VN')->translatedFormat("F")); ?> </span>
                                      <h3> <a href="<?php echo e(route('admission-articles.show',$item->slug)); ?>"><?php echo e($item->title); ?></a> </h3>
                                  </div>
                                  <p class="line-clamp"><?php echo e($item->excerpt); ?>

                                  </p>
                                  <a class="read-more" href="<?php echo e(route('admission-articles.show',$item->slug)); ?>">Xem thêm <i
                                          class="fa fa-long-arrow-right"></i> </a>
                              </div>
                          </div>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12">
                            <?php echo e($posts->links('pages.layouts.partials.paginate')); ?>

                        </div>
                    </div>
                   
                </div>
                <div class="col-md-4 col-sm-5 col-xs-12 pull-right">
                    <aside>
                        <?php echo $__env->make('pages.layouts.partials.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                    </aside>
                </div>
            </div>
        </div>
    </div>
    <!-- Inner Page Wrapper End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/admission-articles/category.blade.php ENDPATH**/ ?>