<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

    <!-- Banner Wrapper Start -->
    <?php echo $__env->make('pages.layouts.partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Banner Wrapper End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Our Services Wrapper Start -->
    <?php if($admission_articles): ?>
        <section class="home-services-wrapper">
            <div class="container">
                <div class="title">
                    <h2>Tuyển sinh</h2>
                    <div><span></span></div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $admission_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($item->link); ?>">
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="single-services">
                                    <div class="services-inner">
                                        <div class="our-services-icon"> <?php echo $item->icons; ?> </div>
                                        <div class="our-services-text" style="margin-right: 20px;">
                                            <h4><?php echo e($item->name); ?></h4>
                                            <p class="line-clamp"><?php echo e($item->excerpt); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <!-- Our Services End -->
    <div class="clearfix"></div>
    <!-- About Us Start -->
    <?php if($about_us): ?>
        <div class="content-section-area-about bg-1" data-stellar-background-ratio="0.5"
             style="background: url(<?php echo e(Voyager::image($about_us->image)); ?>) repeat scroll 0 0;">
            <div class="container-fluid">
                <div class="row margin-left-about">
                    <div class="about-left-hanf">
                        <div class="box bg-cello section-relative">
                            <h3><?php echo e($about_us->title); ?></h3>
                            <p class="wow fadeIn"><?php echo e($about_us->excerpt); ?>.</p>
                            <div class="about-btn"><a class="button active" href="/contact">Liên hệ đăng ký</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <!-- About Us End -->
    <!-- Our Services Wrapper Start -->
    <section class="our-team-wrapper">
        <div class="container">
            <div class="title">
                <h2>Đơn vị thành viên</h2>
                <div><span></span></div>
            </div>
            <div class="row">
                <?php if($our_team): ?>
                    <?php $__currentLoopData = $our_team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="single-blog">
                                <div class="image"><a href="<?php echo e(route('unit-information.show',$item->slug)); ?>">
                                        <img src="<?php echo e(Voyager::image($item->image)); ?>" alt="<?php echo e($item->title); ?>" width="360" height="240"
                                             style="object-fit: cover">
                                    </a>
                                    <a href="<?php echo e(route('unit-information.show',$item->slug)); ?>" class="overlay-box"><span
                                                class="icon fa fa-link"></span></a>
                                </div>
                                <div class="blog-content">
                                    <div class="blog-title">
                                        <h3><a href="<?php echo e(route('unit-information.show',$item->slug)); ?>"><?php echo e($item->title); ?></a></h3>
                                    </div>
                                    <p><?php echo e($item->excerpt); ?></p>
                                    <a class="read-more" href="<?php echo e(route('unit-information.show',$item->slug)); ?>">Xem thêm<i
                                                class="fa fa-long-arrow-right"></i> </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            
        </div>
    </section>
    <!-- Our Services End -->
    <!-- Counter Start -->
    <div class="counters-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="single-counter-item ">
                        <div class="stats-item-heading"><i class="fa fa-user"></i>
                            <h4>Giáo viên</h4>
                        </div>
                        <span class="counter"><?php echo e(setting('count-this.customers')); ?></span>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="single-counter-item ">
                        <div class="stats-item-heading"><i class="fa fa-book"></i>
                            <h4>Khoá học</h4>
                        </div>
                        <span class="counter"><?php echo e(setting('count-this.courses')); ?></span>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="single-counter-item ">
                        <div class="stats-item-heading"><i class="fa fa-graduation-cap"></i>
                            <h4>Học sinh</h4>
                        </div>
                        <span class="counter"><?php echo e(setting('count-this.student')); ?></span>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="single-counter-item ">
                        <div class="stats-item-heading"><i class="fa fa-flag"></i>
                            <h4>Trung tâm</h4>
                        </div>
                        <span class="counter"><?php echo e(setting('count-this.province')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Counter End -->
    <!-- Our Gallery Wrapper Start -->
    <?php if($our_gallery): ?>
        <section class="our-gallery-wrapper">
            <div class="container">
                <div class="title">
                    <h2><?php echo e($our_gallery->name); ?></h2>
                    <div><span></span></div>
                </div>
            </div>
            <div class="container-fluid">
                <div id="home-gallery" class="owl-carousel">
                    <?php if(count(json_decode($our_gallery->images)) > 0): ?>
                        <?php $__currentLoopData = json_decode($our_gallery->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <img src="<?php echo e(Voyager::image($item)); ?>" width="321" height="250"
                                     alt="" style="object-fit: cover">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <!-- Our Gallery Wrapper End -->
    <!-- Testimonials Wrapper Start -->
    <div class="testimonials-wrapper"
         style="height: 500px;background: rgba(0, 0, 0, 0) url(<?php echo e(Voyager::image($banner_image->background)); ?>) no-repeat fixed left top; background-size: cover; background-position: center;">
        <div class="container">
        </div>
    </div>
    <!-- Our Testimonials Wrapper End -->
    <!-- Blog Wrapper Start -->
    <section class="blog-wrapper">
        <div class="container">
            <div class="title">
                <h2>Tin tức, sự kiện</h2>
                <div><span></span></div>
            </div>
            <div class="row">
                <?php if($our_blog): ?>
                    <?php $__currentLoopData = $our_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="single-blog">
                                <div class="image"><a href="<?php echo e(route('posts.show',$item->slug)); ?>">
                                        <img src="<?php echo e(Voyager::image($item->image)); ?>" alt="" width="360" height="240"
                                             style="object-fit: cover">
                                    </a>
                                    <a href="<?php echo e(route('posts.show',$item->slug)); ?>" class="overlay-box"><span
                                                class="icon fa fa-link"></span></a>
                                </div>
                                <div class="blog-content">
                                    <div class="blog-title"> <span><?php echo e(date("d", strtotime($item->created_at))); ?><br>
                    <?php echo e(\Carbon\Carbon::parse($item->created_at)->locale('vi-VN')->translatedFormat("F")); ?>

                  </span>
                                        <h3><a href="<?php echo e(route('posts.show',$item->slug)); ?>"><?php echo e($item->title); ?></a></h3>
                                    </div>
                                    <p><?php echo e($item->excerpt); ?></p>
                                    <a class="read-more" href="<?php echo e(route('posts.show',$item->slug)); ?>">Xem thêm<i
                                                class="fa fa-long-arrow-right"></i> </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- Our Blog Wrapper End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/home/index.blade.php ENDPATH**/ ?>