<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcromb Wrapper Start -->
    <div class="breadcromb-wrapper">
        <div class="breadcromb-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="breadcromb-left">
                        <h3><?php echo e($category->name ?? 'Tin tức & sự kiện'); ?></h3>
                    </div>
                </div>
            </div>
            <div class="breadcromb-text">
                <ul>
                    <li><a href="index.html"><i class="fa fa-home"></i>Trang chủ</a></li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li><?php echo e($category->name ?? 'Tin tức & sự kiện'); ?></li>
                    
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcromb Wrapper End -->
    <!-- grid -->
    
    <!-- grid -->
    <!-- list -->
    <div class="inner-page-wrapper blog-wrapper blog-full-width">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-list clearfix">
                        <div class="blog-list-img">
                            <a href="<?php echo e(route('posts.show',$item->slug)); ?>">
                                <img src="<?php echo e(Voyager::image($item->thumbnail('thumb', 'image'))); ?>" alt="<?php echo e($item->title); ?>" class="img-responsive" title="">
                            </a>
                            <span class="sticker-round "><?php echo e(date("d", strtotime($item->created_at))); ?> <br><?php echo e(date("M", strtotime($item->created_at))); ?></span>
                        </div>
                        <div class="blog-list-details">
                            <a href="<?php echo e(route('posts.show',$item->slug)); ?>">
                                <h4><?php echo e($item->title); ?></h4>
                            </a>
                            <ul class="list-inline list-blog">
                                <li><i class="far fa-clock"></i><a href="<?php echo e(route('posts.show',$item->slug)); ?>"><?php echo e(date("d/m/Y", strtotime($item->created_at))); ?></a></li>
                            </ul>
                            <p><?php echo e($item->excerpt); ?></p>
                            <a href="<?php echo e(route('posts.show',$item->slug)); ?>" class="btn">Xem thêm</a></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <?php echo e($posts->links('pages.layouts.partials.paginate')); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- list -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/posts/index.blade.php ENDPATH**/ ?>