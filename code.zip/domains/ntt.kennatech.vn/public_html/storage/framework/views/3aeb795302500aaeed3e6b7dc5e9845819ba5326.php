<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcromb Wrapper Start -->
    <div class="breadcromb-wrapper">
        <div class="breadcromb-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="breadcromb-left">
                        <h3><?php echo e($pageMeta['title']); ?></h3>
                    </div>
                </div>
            </div>
            <div class="breadcromb-text">
                <ul>
                    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i>Trang chủ</a></li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li>Tin tức</li>
                    <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                    <li><?php echo e($pageMeta['title']); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcromb Wrapper End -->
    <!-- Inner Page Wrapper Start -->
    <div class="inner-page-wrapper blog-wrapper blog-single">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-7 col-xs-12 pull-left">
                    <div class="blog-single-img"> 
                        <?php if($post->image): ?>
                            <img src="<?php echo e(Voyager::image($post->image)); ?>" title="" width="750" height="500" style="object-fit: cover">
                        <?php endif; ?>
                        <h2><?php echo e($post->title); ?></h2>
                        <ul class="list-inline list-blog-single">
                            <li><i class="fa fa-user" aria-hidden="true"></i><a href="javascript:void(0)">Admin</a></li>
                            
                        </ul>
                        <p><?php echo $post->body; ?></p>
                        <ul class="list-inline list-social-color">
                            <li><a target="_blank" href="https://www.facebook.com/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-facebook"></i></a></li>
                            <li><a target="_blank" href="https://twitter.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-5 col-xs-12 pull-right">
                    <aside>
                        <?php echo $__env->make('pages.layouts.partials.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="panel panel-default panel-sidebar ">
                            <div class="panel-heading">
                                <h3><span class="title-about">Tin tức liên quan</span> </h3>
                            </div>
                            <div class="panel-body p0 bn">
                                <ul class="list-unstyled list-panel">
                                  <?php $__currentLoopData = $post_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li> 
                                      <a href="<?php echo e(route('abroad-studies.show',$item->slug)); ?>"> 
                                        <span class="list-image">
                                          <img src="<?php echo e(Voyager::image($item->image)); ?>" alt="" width="97" height="73" style="object-fit: cover"
                                                    class="img-responsive">
                                        </span>
                                        <sapn class="list-title-info"><?php echo e($item->title); ?>

                                                <small><?php echo e(date("F j, Y", strtotime($item->created_at))); ?></small>
                                        </sapn>
                                        </a>
                                      </li>  
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </ul>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>
    <!-- Inner Page Wrapper End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/abroad-studies/show.blade.php ENDPATH**/ ?>