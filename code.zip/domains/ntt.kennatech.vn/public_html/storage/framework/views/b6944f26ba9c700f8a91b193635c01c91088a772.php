<?php
  $menu = menu('pages', '_json');
  // dd(URL::current() == url('/'));
?>

  <div class="top-wrapper hidden-xs">
    <div class="container">
      <div class="pull-left"> <i class="fa fa-map-o" aria-hidden="true"></i> <?php echo e(setting('site.address')); ?> </div>
      <div class="quick-contacts pull-right"> <span><i class="fa fa-phone"></i> <a href="tell:<?php echo e(setting('site.phone')); ?>"><?php echo e(setting('site.phone')); ?></a></span>
         <span>
        <i class="fa fa-envelope"></i><a href="mailto:<?php echo e(setting('site.email')); ?>"><?php echo e(setting('site.email')); ?></a></span>
        
      </div>
    </div>
  </div>
  
  <!-- Navigation Start -->
  <nav class="navbar navbar-default main-navigation affix-top" data-offset-top="197" data-spy="affix">
    <div class="main-menu-header">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
          aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span
            class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(Voyager::image(setting('site.logo'))); ?>" alt=""></a>
      </div>
      <div class="header-search pull-right"> <a class="open-search"> <i class="fa fa-search"></i> </a> </div>
      <div class="collapse navbar-collapse" id="navbar">
        <ul class="nav navbar-nav navbar-right">

          <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($item->children) == 0): ?>
              <li class="<?php if(URL::current() == url($item->url)): ?> active <?php endif; ?>">
                <a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a>
              </li>
            <?php else: ?>
              <li class="dropdown dropdown-toggle">
                <a href="<?php echo e(url($item->url)); ?>" data-toggle="dropdown"><?php echo e($item->title); ?> <i class="fa fa-angle-down"></i></a>
                <ul class="dropdown-menu">
                  <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <a href="<?php echo e(url($value->url)); ?>"><?php echo $value->title; ?></a>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <form class="full-search" action="<?php echo e(url('/search')); ?>" method="get" >
        <div class="container-fluid">
          <div class="row">
            <input class="form-control" placeholder="Search" type="text" name="search">
            <a class="close-search"> <span class="fa fa-times"> </span> </a>
          </div>
        </div>
      </form>
      <ul class="wpb-mobile-menu">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($item->children) == 0): ?>
              <li class="<?php if(URL::current() == url($item->url)): ?> active <?php endif; ?>">
                <a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a>
              </li>
            <?php else: ?>
              <li >
                <a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?> </a>
                <ul >
                  <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <a href="<?php echo e(url($value->url)); ?>"><?php echo $value->title; ?></a>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </nav>
  <!-- Navigation End -->

<?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/layouts/partials/header.blade.php ENDPATH**/ ?>