<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Breadcromb Wrapper Start -->
<div class="breadcromb-wrapper">
  <div class="breadcromb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="breadcromb-left">
          <h3>Liên hệ với chúng tôi</h3>
        </div>
      </div>
    </div>
    <div class="breadcromb-text">
      <ul>
        <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i>Trang chủ</a></li>
        <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
        <li>Liên hệ</li>
        
      </ul>
    </div>
  </div>
</div>
<!-- Breadcromb Wrapper End --> 
<!-- Inner Page Wrapper Start -->
<div class="inner-page-wrapper contact-wrapper" style="padding: 80px 0 0 0;">
  <div class="container">
  <div class="row">
  <div class="col-md-8">
  <div class="contact-form">
  <h3>Liên hệ</h3>
 <form  method="post" action="<?php echo e(route('contact.store')); ?>">
  <?php echo csrf_field(); ?>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <input class="form-control" id="nameId" required name="name" placeholder="Họ và tên" type="text"  value="<?php echo e(request()->name ?? ''); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text_error">Tên không được để trống</p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>
    <!-- .col-md-6 -->
    <div class="col-md-6">
      <div class="form-group">
        <input class="form-control" id="emailId" required name="email" placeholder="Địa chỉ email" type="email" value="<?php echo e(request()->email ?? ''); ?>">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text_error">Email không đúng định dạng</p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>
    <!-- .col-md-6 --> 
  </div>
  <div class="form-group">
    <input class="form-control" id="subjectId" required name="phone" placeholder="Số điện thoại" type="text" value="<?php echo e(request()->phone ?? ''); ?>">
    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text_error">Số điện thoại không đúng</p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <textarea class="form-control text-area" rows="3" name="content" placeholder="Lời nhắn..."></textarea>
  <button type="submit" class="btn btn-default">Gửi</button>
</form>
  </div>
  </div>
  <div class="col-md-4">
  <div class="address">
  <h3 class="contact-title">Chi tiết liên hệ</h3>
  <ul class="contact-address">
    <li>  <div class="contact-content">
      <p><?php echo e(setting('site.address')); ?></p>
      </div>
    </li>
    <li>  <div class="contact-content">
        <p><?php echo e(setting('site.phone')); ?></p>
      </div>
    </li>
    <li> <div class="contact-content">
      <p><?php echo e(setting('site.email')); ?></p>
      </div>
    </li>
  </ul>
  <ul class="social-icon-rounded contact-social-icon">
    <li><a href="<?php echo e(setting('social-media.facebook')); ?>"><i class="fa fa-facebook"></i></a></li>
    <li><a href="<?php echo e(setting('social-media.twitter')); ?>"><i class="fa fa-twitter"></i></a></li>
    <li><a href="<?php echo e(setting('social-media.instagram')); ?>"><i class="fa fa-instagram"></i></a></li>
    <li><a href="<?php echo e(setting('social-media.youtube')); ?>"><i class="fa fa-youtube"></i></a></li>
  </ul>
</div>

  </div>
  </div>
  </div>
  <!-- Google Map Start --> 
<div class="google-map">
  <?php echo setting('site.google-map'); ?>

</div>
<!-- Google Map End --> 
</div>
<!-- Inner Page Wrapper End --> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ntt/domains/ntt.kennatech.vn/public_html/resources/views/pages/contact/index.blade.php ENDPATH**/ ?>